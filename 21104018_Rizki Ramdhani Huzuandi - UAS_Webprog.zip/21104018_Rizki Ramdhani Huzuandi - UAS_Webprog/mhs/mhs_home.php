<?php
    include '../template/mhs_nav.php';
?>

<div class="container">
  <h3>SELAMAT DATANG DI SISTEM INFORMASI INSTIKI</h3>
  <p>Ini adalah halaman informasi bagi mahasiswa dan Dosen INSTIKI.</p>
  <hr>
</div>

<?php
    include '../template/footer.php';
?>