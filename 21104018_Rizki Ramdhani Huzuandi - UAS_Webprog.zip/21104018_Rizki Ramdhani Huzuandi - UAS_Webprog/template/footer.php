</body>

<style>
.footer {
  position: fixed;
  bottom: 0;
}
</style>
<!-- Footer -->
<div class="footer">
<footer class="page-footer blue" >
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2022 Copyright:
        <a href="https://rizki.com"> rizki.com</a>
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->
</div>
</html>