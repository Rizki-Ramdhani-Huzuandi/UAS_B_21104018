<?php
  include '../template/adm_nav.php';
?>

<div class="container">
  <h3>Selamat datang ADMIN di Sistem Informasi Mahasiswa (SIMas)</h3>
  <p>Ini adalah halaman informasi bagi mahasiswa dan dosen INSTIKI</p>
  <hr>
</div>

<?php
    include '../template/footer.php';
?>